import connexion
import six

from swagger_server import util


def get_jobs(limit=None, status=None, type=None, process_id=None, _datetime=None, min_duration=None, max_duration=None):  # noqa: E501
    """get_jobs

    retrieve the list of jobs # noqa: E501

    :param limit: number of jobs to get
    :type limit: int
    :param status: status of the jobs to be listed
    :type status: str
    :param type: type of the jobs to be listed
    :type type: str
    :param process_id: processID of the jobs to listed
    :type process_id: str
    :param _datetime: datetime or interval the created timestamp of a job must match
    :type _datetime: str
    :param min_duration: minimal duration of listed jobs
    :type min_duration: int
    :param max_duration: maximal duration of listed jobs
    :type max_duration: int

    :rtype: str
    """
    return 'do some magic!'
