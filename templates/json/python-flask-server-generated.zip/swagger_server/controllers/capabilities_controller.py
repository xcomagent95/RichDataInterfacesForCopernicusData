import connexion
import six

from swagger_server import util


def get_landing_page():  # noqa: E501
    """get_landing_page

    landing page for this API providing links to other resources # noqa: E501


    :rtype: str
    """
    return 'do some magic!'
