import connexion
import six

from swagger_server import util


def get_status(job_id):  # noqa: E501
    """get_status

    retrieve the status of a specific job # noqa: E501

    :param job_id: numeric id of the user to get
    :type job_id: int

    :rtype: str
    """
    return 'do some magic!'
