import connexion
import six

from swagger_server import util


def get_processes(limit=None):  # noqa: E501
    """get_processes

    retrieve the list of available processes # noqa: E501

    :param limit: number of process descriptions to get
    :type limit: int

    :rtype: str
    """
    return 'do some magic!'
