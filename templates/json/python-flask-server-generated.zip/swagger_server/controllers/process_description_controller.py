import connexion
import six

from swagger_server import util


def get_process_description(process_id):  # noqa: E501
    """get_process_description

    retrieve the process description of a specific process # noqa: E501

    :param process_id: id of the process to get
    :type process_id: int

    :rtype: str
    """
    return 'do some magic!'
