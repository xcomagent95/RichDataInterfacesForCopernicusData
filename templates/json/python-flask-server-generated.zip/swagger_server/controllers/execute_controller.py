import connexion
import six

from swagger_server.models.exception import Exception  # noqa: E501
from swagger_server.models.execute import Execute  # noqa: E501
from swagger_server import util


def execute(body, process_id):  # noqa: E501
    """execute

    execute a process # noqa: E501

    :param body: mandatory execute request JSON
    :type body: dict | bytes
    :param process_id: id of the process to execute
    :type process_id: str

    :rtype: str
    """
    if connexion.request.is_json:
        body = Execute.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
