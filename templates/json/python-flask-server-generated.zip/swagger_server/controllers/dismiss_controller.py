import connexion
import six

from swagger_server.models.exception import Exception  # noqa: E501
from swagger_server.models.status_info import StatusInfo  # noqa: E501
from swagger_server import util


def dismiss(job_id):  # noqa: E501
    """dismiss

    dismiss a specific job # noqa: E501

    :param job_id: numeric ID of the user to get
    :type job_id: int

    :rtype: str
    """
    return 'do some magic!'
