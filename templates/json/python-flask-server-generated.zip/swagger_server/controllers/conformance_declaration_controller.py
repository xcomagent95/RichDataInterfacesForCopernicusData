import connexion
import six

from swagger_server import util


def get_conformance_classes():  # noqa: E501
    """get_conformance_classes

    information about requiremnt classes that this API conforms to # noqa: E501


    :rtype: str
    """
    return 'do some magic!'
