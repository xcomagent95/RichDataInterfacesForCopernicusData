import connexion
import six

from swagger_server import util


def get_coverage():  # noqa: E501
    """get_coverage

    retrieve the coverage for which offline datasets are available # noqa: E501


    :rtype: str
    """
    return 'do some magic!'
