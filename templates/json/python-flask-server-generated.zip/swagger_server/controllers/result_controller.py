import connexion
import six

from swagger_server.models.exception import Exception  # noqa: E501
from swagger_server.models.results import Results  # noqa: E501
from swagger_server import util


def get_result(job_id):  # noqa: E501
    """get_result

    retrieve the result(s) of a specific job # noqa: E501

    :param job_id: numeric id of the user to get
    :type job_id: int

    :rtype: Results
    """
    return 'do some magic!'
