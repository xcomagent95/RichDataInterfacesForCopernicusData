# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.exception import Exception  # noqa: E501
from swagger_server.models.execute import Execute  # noqa: E501
from swagger_server.test import BaseTestCase


class TestExecuteController(BaseTestCase):
    """ExecuteController integration test stubs"""

    def test_execute(self):
        """Test case for execute

        
        """
        body = Execute()
        response = self.client.open(
            '/RDIForCopernicusData/RichDataInterfaceForCopernicusData/1.0.0/processes/{processID}/execution'.format(process_id='process_id_example'),
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
