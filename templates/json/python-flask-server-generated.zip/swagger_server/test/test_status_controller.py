# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.test import BaseTestCase


class TestStatusController(BaseTestCase):
    """StatusController integration test stubs"""

    def test_get_status(self):
        """Test case for get_status

        
        """
        response = self.client.open(
            '/RDIForCopernicusData/RichDataInterfaceForCopernicusData/1.0.0/jobs/{jobID}'.format(job_id=56),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
