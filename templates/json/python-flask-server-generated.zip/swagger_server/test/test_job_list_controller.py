# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.test import BaseTestCase


class TestJobListController(BaseTestCase):
    """JobListController integration test stubs"""

    def test_get_jobs(self):
        """Test case for get_jobs

        
        """
        query_string = [('limit', 1000),
                        ('status', 'status_example'),
                        ('type', 'type_example'),
                        ('process_id', 'process_id_example'),
                        ('_datetime', '_datetime_example'),
                        ('min_duration', 56),
                        ('max_duration', 56)]
        response = self.client.open(
            '/RDIForCopernicusData/RichDataInterfaceForCopernicusData/1.0.0/jobs',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
