#!/usr/bin/env python3

import connexion

from swagger_server import encoder


def main():
    app = connexion.App(__name__, specification_dir='./swagger/')
    app.app.json_encoder = encoder.JSONEncoder
    app.add_api('swagger.yaml', arguments={'title': 'A rich data interface for copernicus data conforming to the OGC API - Processes - Part 1: Core standard'}, pythonic_params=True)
    app.run(port=5000)


if __name__ == '__main__':
    main()
